# Implementierungsplan: ColorScale Background Script

## Ziel
Hintergrundfarben von Shapes mit dem Namen "ColorScaleBackground" in einer PPTX-Datei gleichmäßig von `#4da8f9` (Blau) bis `#f7c542` (Gold) interpolieren.

## Analyse der PPTX-Datei
- **Datei:** `ColorScaleTest.pptx` (10 Folien)
- **Betroffene Folien:** Slide 3–9 (7 Folien haben ein Rechteck namens "ColorScaleBackground")
- **Slide 1, 2, 10:** Kein ColorScaleBackground → werden nicht verändert
- **XML-Struktur:** Jede Shape enthält `<a:solidFill><a:srgbClr val="XXXXXX"/></a:solidFill>`

## Implementierungsschritte

### 1. PPTX kopieren
- `ColorScaleTest.pptx` → `ColorScaleTest-colorscale.pptx`
- Einfache Dateikopie mit `shutil.copy2`

### 2. ZIP entpacken & Slides identifizieren
- PPTX als ZIP öffnen (`zipfile`-Modul)
- Alle `ppt/slides/slideN.xml` durchgehen
- Per String-Suche prüfen, ob `name="ColorScaleBackground"` vorkommt
- Liste der betroffenen Slide-Dateien erstellen (geordnet nach Foliennummer)

### 3. Farbverlauf berechnen
- Startfarbe: `#4da8f9` → RGB (77, 168, 249)
- Endfarbe: `#f7c542` → RGB (247, 197, 66)
- Bei n gefundenen Folien: lineare Interpolation für Index i = 0..n-1
- Formel: `color[i] = start + (end - start) * i / (n - 1)`

### 4. XML modifizieren
- In jeder betroffenen Slide-XML den Wert von `<a:srgbClr val="..."/>` innerhalb des ColorScaleBackground-Shapes ersetzen
- Regex-basiert: Finde das `<p:sp>`-Element mit `name="ColorScaleBackground"` und ersetze darin `<a:srgbClr val="..."/>`

### 5. ZIP neu schreiben
- Kopierte PPTX als ZIP öffnen
- Modifizierte Slide-XMLs ersetzen
- Alle anderen Dateien unverändert übernehmen

## Abhängigkeiten
- Nur Python-Standardbibliothek: `zipfile`, `shutil`, `re`, `os`

## Erwartetes Ergebnis
7 Folien mit gleichmäßigem Farbverlauf:
| Folie | Farbe |
|-------|-------|
| 3 | #4da8f9 (Start) |
| 4 | #63b0c0 |
| 5 | #79b887 |
| 6 | #8fc04e |
| 7 | #b5bc48 |
| 8 | #cbc443 |
| 9 | #f7c542 (End) |

*(Ungefähre Werte, exakte Berechnung im Script)*
